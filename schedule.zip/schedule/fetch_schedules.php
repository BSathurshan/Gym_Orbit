<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gym_schedule";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the database
$sql = "SELECT id, instructor_name, schedule_date, schedule_time, gym_member_name FROM instructor_schedule";
$result = $conn->query($sql);

$schedules = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $schedules[] = $row;
    }
}

// Output as JSON
header('Content-Type: application/json');
echo json_encode($schedules);

$conn->close();
?>
