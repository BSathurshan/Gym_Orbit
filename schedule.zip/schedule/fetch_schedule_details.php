<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gym_schedule";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data for a specific day
if (isset($_GET['day'])) {
    $day = $_GET['day'];

    // Query to fetch schedules for the specific day
    $stmt = $conn->prepare("SELECT schedule_date, schedule_time, instructor_name FROM instructor_schedule WHERE schedule_date = ?");
    $stmt->bind_param("s", $day);
    $stmt->execute();
    $result = $stmt->get_result();

    $schedules = [];
    while ($row = $result->fetch_assoc()) {
        $schedules[] = $row;
    }

    // Return the data as JSON
    echo json_encode($schedules);
}

$conn->close();
?>
