<?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = ""; // Default XAMPP password is empty
$dbname = "gym_schedule";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $instructorName = $_POST['instructorName'];
    $scheduleDate = $_POST['scheduleDate'];
    $scheduleTime = $_POST['scheduleTime'];
    $gymMemberName = $_POST['gymMemberName'];

    // Prepare and bind SQL statement
    $stmt = $conn->prepare("INSERT INTO instructor_schedule (instructor_name, schedule_date, schedule_time, gym_member_name) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $instructorName, $scheduleDate, $scheduleTime, $gymMemberName);

    if ($stmt->execute()) {
        echo "Schedule added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
