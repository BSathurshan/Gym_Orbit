<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gym_schedule";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
} else {
    echo "Connected to the database successfully!";
}

$conn->close();
?>

