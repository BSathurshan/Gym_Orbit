<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gym_schedule";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle DELETE request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];

    // Validate ID
    if (!empty($id) && is_numeric($id)) {
        $stmt = $conn->prepare("DELETE FROM instructor_schedule WHERE id = ?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            echo json_encode(["success" => true, "message" => "Schedule deleted successfully."]);
        } else {
            echo json_encode(["success" => false, "message" => "Error deleting schedule: " . $stmt->error]);
        }

        $stmt->close();
    } else {
        echo json_encode(["success" => false, "message" => "Invalid ID."]);
    }
}

$conn->close();
?>
